ZENYX PREMIUM — FREE WEBSITE STARTER

Included:
- index.html: responsive clothing storefront with product cards and WhatsApp order form.

Before publishing:
1. Open index.html in a text editor.
2. Search for WHATSAPP_NUMBER = "8801XXXXXXXXX"
3. The WhatsApp number is already set to 8801306995177. If you change business numbers later, use digits only.
4. Edit product names/prices and photo URLs in the `products` list to match your actual stock.
5. Test the page by opening index.html in a browser and placing a test order.

Free publishing options:
- GitHub Pages (free, but requires a GitHub account and a few setup steps)
- Netlify Drop (free plan may be available; upload the site folder or its files)
A custom domain is optional and usually costs extra. This starter does not process online payments; orders are sent to WhatsApp.
